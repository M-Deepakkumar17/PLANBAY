import random
from fastapi import APIRouter, HTTPException

from database.mongodb import destinations_collection, feedback_collection, search_history_collection
from models.destination import TripPreferenceRequest
from ai.recommender import rank_destinations

router = APIRouter(prefix="/recommend", tags=["Recommendations"])


@router.post("")
def recommend_trip(preferences: TripPreferenceRequest):
    destinations = list(destinations_collection.find({}, {"_id": 0}))
    if not destinations:
        raise HTTPException(status_code=404, detail="No destinations found. Please seed the database first.")

    prefs = preferences.dict()

    user_feedback = []
    if preferences.user_id:
        user_feedback = list(feedback_collection.find({"user_id": preferences.user_id}, {"_id": 0}))
        search_history_collection.insert_one({"user_id": preferences.user_id, "query": prefs})

    ranked = rank_destinations(prefs, destinations, user_feedback=user_feedback, top_n=5)
    return {"recommendations": ranked}


@router.post("/surprise-me")
def surprise_me(preferences: TripPreferenceRequest):
    """'Surprise Me' — user only gives budget/days/travelers, AI explores
    across trip themes (Nature, Beach, Hill Station, Heritage, Adventure)."""
    themes = ["Nature", "Beach", "Hill Station", "Heritage", "Adventure", "Wildlife"]
    prefs = preferences.dict()
    prefs["interests"] = prefs.get("interests") or random.sample(themes, k=min(3, len(themes)))

    destinations = list(destinations_collection.find({}, {"_id": 0}))
    if not destinations:
        raise HTTPException(status_code=404, detail="No destinations found. Please seed the database first.")

    ranked = rank_destinations(prefs, destinations, top_n=5)
    return {"theme_explored": prefs["interests"], "recommendations": ranked}


@router.get("/destinations")
def list_destinations():
    return {"destinations": list(destinations_collection.find({}, {"_id": 0}))}
