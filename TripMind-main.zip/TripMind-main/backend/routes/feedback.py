from fastapi import APIRouter

from database.mongodb import feedback_collection
from models.itinerary import FeedbackRequest

router = APIRouter(prefix="/feedback", tags=["Feedback"])


@router.post("")
def submit_feedback(fb: FeedbackRequest):
    """Store feedback — this is what feeds the 'preference learning' loop
    inside ai/recommender.py (see _feedback_boost)."""
    feedback_collection.insert_one(fb.dict())
    return {"message": "Thanks! We'll use this to improve your future recommendations."}


@router.get("/{user_id}")
def get_user_feedback(user_id: str):
    return {"feedback": list(feedback_collection.find({"user_id": user_id}, {"_id": 0}))}
