from fastapi import APIRouter, Depends, HTTPException

from database.mongodb import (
    users_collection,
    destinations_collection,
    itineraries_collection,
    feedback_collection,
)
from models.destination import Destination
from utils.security import require_admin

router = APIRouter(prefix="/admin", tags=["Admin"])


@router.get("/stats")
def admin_stats(_: dict = Depends(require_admin)):
    return {
        "total_users": users_collection.count_documents({}),
        "total_destinations": destinations_collection.count_documents({}),
        "total_itineraries": itineraries_collection.count_documents({}),
        "total_feedback": feedback_collection.count_documents({}),
    }


@router.get("/users")
def admin_list_users(_: dict = Depends(require_admin)):
    return {"users": list(users_collection.find({}, {"_id": 0, "password_hash": 0}))}


@router.post("/destinations")
def admin_add_destination(destination: Destination, _: dict = Depends(require_admin)):
    if destinations_collection.find_one({"destination": destination.destination}):
        raise HTTPException(status_code=400, detail="Destination already exists")
    destinations_collection.insert_one(destination.dict())
    return {"message": f"Destination '{destination.destination}' added"}


@router.put("/destinations/{name}")
def admin_update_destination(name: str, destination: Destination, _: dict = Depends(require_admin)):
    result = destinations_collection.update_one({"destination": name}, {"$set": destination.dict()})
    if result.matched_count == 0:
        raise HTTPException(status_code=404, detail="Destination not found")
    return {"message": f"Destination '{name}' updated"}


@router.delete("/destinations/{name}")
def admin_delete_destination(name: str, _: dict = Depends(require_admin)):
    result = destinations_collection.delete_one({"destination": name})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Destination not found")
    return {"message": f"Destination '{name}' deleted"}
