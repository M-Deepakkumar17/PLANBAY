import uuid
from datetime import date

from fastapi import APIRouter, HTTPException

from database.mongodb import users_collection, admins_collection
from models.user import UserRegister, UserLogin, AdminLogin
from utils.security import hash_password, verify_password, create_access_token

router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register")
def register(user: UserRegister):
    if users_collection.find_one({"email": user.email}):
        raise HTTPException(status_code=400, detail="Email already registered")

    user_id = f"USR{uuid.uuid4().hex[:8].upper()}"
    doc = {
        "user_id": user_id,
        "name": user.name,
        "email": user.email,
        "password_hash": hash_password(user.password),
        "budget": user.budget,
        "travelers": user.travelers,
        "preferences": user.preferences.dict() if user.preferences else {
            "interests": [], "food": "Any", "travel_style": "Balanced", "accommodation": "Budget"
        },
        "created_at": str(date.today()),
    }
    users_collection.insert_one(doc)

    token = create_access_token({"sub": user_id, "email": user.email, "role": "user"})
    return {"access_token": token, "token_type": "bearer", "user_id": user_id, "name": user.name}


@router.post("/login")
def login(credentials: UserLogin):
    user = users_collection.find_one({"email": credentials.email})
    if not user or not verify_password(credentials.password, user.get("password_hash", "")):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    token = create_access_token({"sub": user["user_id"], "email": user["email"], "role": "user"})
    return {
        "access_token": token,
        "token_type": "bearer",
        "user_id": user["user_id"],
        "name": user["name"],
    }


@router.post("/admin-login")
def admin_login(credentials: AdminLogin):
    """
    Admin login. The admin account is seeded automatically on server
    startup from ADMIN_EMAIL / ADMIN_PASSWORD in your .env file
    (see backend/seed/seed_admin.py).
    """
    admin = admins_collection.find_one({"email": credentials.email})
    if not admin or not verify_password(credentials.password, admin.get("password_hash", "")):
        raise HTTPException(status_code=401, detail="Invalid admin credentials")

    token = create_access_token({"sub": admin["admin_id"], "email": admin["email"], "role": "admin"})
    return {
        "access_token": token,
        "token_type": "bearer",
        "name": admin.get("name", "Admin"),
        "role": "admin",
    }
