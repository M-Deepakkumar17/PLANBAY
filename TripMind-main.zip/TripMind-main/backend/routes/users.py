from fastapi import APIRouter, HTTPException, Depends

from database.mongodb import users_collection, itineraries_collection, feedback_collection
from utils.security import get_current_user

router = APIRouter(prefix="/users", tags=["Users"])


@router.get("/me")
def get_profile(current_user: dict = Depends(get_current_user)):
    user = users_collection.find_one({"user_id": current_user["sub"]}, {"_id": 0, "password_hash": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.get("/{user_id}/dashboard")
def get_dashboard(user_id: str):
    user = users_collection.find_one({"user_id": user_id}, {"_id": 0, "password_hash": 0})
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    trips = list(itineraries_collection.find({"user_id": user_id}, {"_id": 0}))
    feedbacks = list(feedback_collection.find({"user_id": user_id}, {"_id": 0}))

    destinations_visited = {t["destination"] for t in trips}
    match_scores = [t.get("match_score") for t in trips if t.get("match_score") is not None]
    avg_match = round(sum(match_scores) / len(match_scores)) if match_scores else 0

    # Travel personality from feedback categories
    personality: dict = {}
    for fb in feedbacks:
        for cat in fb.get("liked", []):
            personality[cat] = personality.get(cat, 0) + fb.get("rating", 3)
    if personality:
        max_val = max(personality.values())
        personality = {k: round(min(100, v / max_val * 100)) for k, v in personality.items()}

    return {
        "user": user,
        "trips_planned": len(trips),
        "destinations_count": len(destinations_visited),
        "avg_ai_match": avg_match,
        "travel_personality": personality,
        "recent_trips": trips[-5:],
    }
