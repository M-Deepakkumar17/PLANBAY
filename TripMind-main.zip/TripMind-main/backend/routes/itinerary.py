import uuid
from fastapi import APIRouter, HTTPException

from database.mongodb import destinations_collection, itineraries_collection
from models.itinerary import ItineraryGenerateRequest, DayReplanRequest
from ai.itinerary_generator import generate_itinerary, replan_day
from utils.budget import estimate_trip_budget

router = APIRouter(prefix="/itinerary", tags=["Itinerary"])


def _get_destination_or_404(name: str):
    dest = destinations_collection.find_one({"destination": name}, {"_id": 0})
    if not dest:
        raise HTTPException(status_code=404, detail=f"Destination '{name}' not found")
    return dest


@router.post("/generate")
def generate(req: ItineraryGenerateRequest):
    destination = _get_destination_or_404(req.destination)

    result = generate_itinerary(
        destination=destination,
        days=req.days,
        budget=req.budget,
        travelers=req.travelers,
        interests=req.interests,
    )

    budget_summary = estimate_trip_budget(
        average_daily_cost=destination.get("average_daily_cost", 3000),
        days=req.days,
        travelers=req.travelers,
        total_budget=req.budget,
    )

    itinerary_id = f"ITN{uuid.uuid4().hex[:10].upper()}"
    doc = {
        "itinerary_id": itinerary_id,
        "user_id": req.user_id or "guest",
        "destination": req.destination,
        "days": req.days,
        "budget": req.budget,
        "travelers": req.travelers,
        "match_score": req.match_score,
        "itinerary": result["itinerary"],
        "estimated_cost": result["estimated_cost"],
        "remaining_budget": result["remaining_budget"],
        "budget_summary": budget_summary,
        "generator": result.get("generator"),
    }
    itineraries_collection.insert_one(doc.copy())
    doc.pop("_id", None)
    return doc


@router.get("/{itinerary_id}")
def get_itinerary(itinerary_id: str):
    itn = itineraries_collection.find_one({"itinerary_id": itinerary_id}, {"_id": 0})
    if not itn:
        raise HTTPException(status_code=404, detail="Itinerary not found")
    return itn


@router.get("/user/{user_id}")
def get_user_itineraries(user_id: str):
    return {"itineraries": list(itineraries_collection.find({"user_id": user_id}, {"_id": 0}))}


@router.post("/replan-day")
def replan(req: DayReplanRequest):
    """AI Trip Re-Planner — regenerate a single day without touching the rest."""
    itn = itineraries_collection.find_one({"itinerary_id": req.itinerary_id})
    if not itn:
        raise HTTPException(status_code=404, detail="Itinerary not found")

    destination = _get_destination_or_404(itn["destination"])
    budget_per_day = itn["budget"] / itn["days"] if itn["days"] else itn["budget"]

    new_day = replan_day(
        destination=destination,
        day_number=req.day,
        avoid_activity=req.avoid_activity or "",
        travelers=itn.get("travelers", 1),
        budget_per_day=budget_per_day,
    )

    updated_days = [d for d in itn["itinerary"] if d["day"] != req.day] + [new_day]
    updated_days.sort(key=lambda d: d["day"])
    total_cost = sum(d["estimated_cost"] for d in updated_days)

    itineraries_collection.update_one(
        {"itinerary_id": req.itinerary_id},
        {"$set": {"itinerary": updated_days, "estimated_cost": total_cost,
                   "remaining_budget": round(itn["budget"] - total_cost)}},
    )
    return {"itinerary_id": req.itinerary_id, "updated_day": new_day, "estimated_cost": total_cost}
