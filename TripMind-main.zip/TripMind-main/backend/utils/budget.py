"""
Budget AI — breaks down an estimated day cost into categories:
Transport + Accommodation + Food + Activities + Local Transport + Emergency Buffer
"""
from typing import Dict


def estimate_day_cost(average_daily_cost: float, travelers: int = 1, budget_cap: float = None) -> Dict[str, float]:
    per_person = average_daily_cost
    total_base = per_person * max(1, travelers)

    # If a per-day budget cap is supplied, scale the base cost down so the
    # generated plan stays within the traveler's budget instead of just
    # using the destination's average cost regardless of what they can spend.
    if budget_cap and total_base > budget_cap:
        total_base = budget_cap * 0.95  # leave a small safety margin

    breakdown = {
        "accommodation": round(total_base * 0.30),
        "food": round(total_base * 0.22),
        "activities": round(total_base * 0.20),
        "local_transport": round(total_base * 0.13),
        "transport": round(total_base * 0.10),
        "emergency_buffer": round(total_base * 0.05),
    }
    total = sum(breakdown.values())
    breakdown["total"] = total
    return breakdown


def estimate_trip_budget(average_daily_cost: float, days: int, travelers: int, total_budget: float) -> Dict:
    per_day = estimate_day_cost(average_daily_cost, travelers)
    estimated_total = per_day["total"] * days
    return {
        "per_day_breakdown": per_day,
        "days": days,
        "estimated_total": estimated_total,
        "budget": total_budget,
        "remaining": round(total_budget - estimated_total),
        "within_budget": estimated_total <= total_budget,
    }
