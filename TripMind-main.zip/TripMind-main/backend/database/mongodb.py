"""
MongoDB connection setup for TripMind.

Keeps the exact database / collection names from the original project spec:
    Database:   Travel_Assistant
    Collection: Users_Data   (already created by the user)
Additional collections are created automatically the first time
documents are inserted into them (MongoDB creates collections lazily).
"""
import os
from pymongo import MongoClient
from dotenv import load_dotenv

load_dotenv()

MONGO_URL = os.getenv("MONGO_URL", "mongodb://localhost:27017/")
DB_NAME = os.getenv("MONGO_DB_NAME", "Travel_Assistant")

client = MongoClient(MONGO_URL, serverSelectionTimeoutMS=5000)
db = client[DB_NAME]

# Collections
users_collection = db["Users_Data"]
destinations_collection = db["Destinations"]
itineraries_collection = db["Itineraries"]
feedback_collection = db["Travel_Feedback"]
search_history_collection = db["Search_History"]
admins_collection = db["Admins"]


def check_connection() -> bool:
    """Quick health check used by the /health endpoint."""
    try:
        client.admin.command("ping")
        return True
    except Exception:
        return False


def ensure_indexes():
    """Create useful indexes. Safe to call on every startup (idempotent)."""
    users_collection.create_index("email", unique=True)
    admins_collection.create_index("email", unique=True)
    destinations_collection.create_index("destination")
    itineraries_collection.create_index("user_id")
    feedback_collection.create_index([("user_id", 1), ("destination", 1)])
