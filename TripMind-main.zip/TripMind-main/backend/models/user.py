from typing import List, Optional
from pydantic import BaseModel, EmailStr, Field


class Preferences(BaseModel):
    interests: List[str] = Field(default_factory=list)
    food: str = "Any"
    travel_style: str = "Balanced"
    accommodation: str = "Budget"


class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str
    budget: Optional[float] = 0
    travelers: Optional[int] = 1
    preferences: Optional[Preferences] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class AdminLogin(BaseModel):
    email: EmailStr
    password: str


class UserPublic(BaseModel):
    user_id: str
    name: str
    email: EmailStr
    budget: Optional[float] = 0
    travelers: Optional[int] = 1
    preferences: Optional[Preferences] = None
    created_at: Optional[str] = None
