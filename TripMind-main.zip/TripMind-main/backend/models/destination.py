from typing import List, Optional
from pydantic import BaseModel


class Destination(BaseModel):
    destination: str
    state: Optional[str] = None
    categories: List[str] = []
    budget_level: str = "Medium"
    average_daily_cost: float = 3000
    minimum_days: int = 2
    best_months: List[str] = []
    activities: List[str] = []
    food: List[str] = []
    travel_style: Optional[str] = "Balanced"
    rating: float = 4.5


class TripPreferenceRequest(BaseModel):
    location: str
    destination_preference: Optional[str] = "Surprise Me"
    days: int
    budget: float
    travelers: int = 1
    travel_type: Optional[str] = "Balanced"
    interests: List[str] = []
    activities: List[str] = []
    food: Optional[str] = "Any"
    accommodation: Optional[str] = "Budget"
    travel_month: Optional[str] = None
    pace: Optional[str] = "Medium"
    user_id: Optional[str] = None
