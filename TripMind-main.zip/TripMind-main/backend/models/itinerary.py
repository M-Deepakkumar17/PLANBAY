from typing import List, Optional
from pydantic import BaseModel


class ItineraryGenerateRequest(BaseModel):
    user_id: Optional[str] = "guest"
    destination: str
    days: int
    budget: float
    travelers: int = 1
    interests: List[str] = []
    pace: Optional[str] = "Medium"
    match_score: Optional[int] = None


class DayReplanRequest(BaseModel):
    itinerary_id: str
    day: int
    avoid_activity: Optional[str] = None
    note: Optional[str] = None


class FeedbackRequest(BaseModel):
    user_id: str
    destination: str
    rating: int
    liked: List[str] = []
    disliked: List[str] = []
    feedback: Optional[str] = ""
