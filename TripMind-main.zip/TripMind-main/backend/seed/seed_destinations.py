"""
Seeds the Destinations collection with a starter dataset (only runs if
the collection is empty, so it's safe to call on every startup).
Feel free to add more destinations via the admin API/panel later.
"""
from database.mongodb import destinations_collection

DESTINATIONS = [
    {
        "destination": "Munnar", "state": "Kerala",
        "categories": ["Nature", "Adventure", "Romantic"],
        "budget_level": "Medium", "average_daily_cost": 3500, "minimum_days": 3,
        "best_months": ["October", "November", "December", "January", "February"],
        "activities": ["Tea Garden Tour", "Trekking", "Boating at Mattupetty", "Eravikulam National Park",
                        "Echo Point Visit", "Waterfalls Trip", "Tea Museum"],
        "food": ["Kerala Cuisine", "Vegetarian"], "travel_style": "Balanced", "rating": 4.7,
    },
    {
        "destination": "Coorg", "state": "Karnataka",
        "categories": ["Nature", "Adventure", "Romantic"],
        "budget_level": "Medium", "average_daily_cost": 3200, "minimum_days": 3,
        "best_months": ["October", "November", "December", "January", "February", "March"],
        "activities": ["Coffee Plantation Walk", "Abbey Falls", "Trekking Tadiandamol", "River Rafting",
                        "Dubare Elephant Camp", "Raja's Seat Sunset"],
        "food": ["Coorgi Cuisine", "Non-Vegetarian", "Vegetarian"], "travel_style": "Balanced", "rating": 4.6,
    },
    {
        "destination": "Wayanad", "state": "Kerala",
        "categories": ["Nature", "Adventure", "Wildlife"],
        "budget_level": "Low", "average_daily_cost": 2800, "minimum_days": 3,
        "best_months": ["October", "November", "December", "January", "February"],
        "activities": ["Edakkal Caves", "Chembra Peak Trek", "Wildlife Safari", "Banasura Sagar Dam",
                        "Soochipara Waterfalls", "Bamboo Rafting"],
        "food": ["Kerala Cuisine", "Vegetarian"], "travel_style": "Adventure", "rating": 4.5,
    },
    {
        "destination": "Ooty", "state": "Tamil Nadu",
        "categories": ["Nature", "Hill Station", "Family"],
        "budget_level": "Low", "average_daily_cost": 2500, "minimum_days": 2,
        "best_months": ["April", "May", "June", "September", "October"],
        "activities": ["Botanical Garden", "Ooty Lake Boating", "Doddabetta Peak", "Toy Train Ride",
                        "Tea Museum", "Rose Garden"],
        "food": ["South Indian", "Vegetarian"], "travel_style": "Relaxed", "rating": 4.3,
    },
    {
        "destination": "Goa", "state": "Goa",
        "categories": ["Beach", "Nightlife", "Adventure"],
        "budget_level": "Medium", "average_daily_cost": 4000, "minimum_days": 2,
        "best_months": ["November", "December", "January", "February"],
        "activities": ["Baga Beach", "Water Sports", "Fort Aguada", "Old Goa Churches",
                        "Anjuna Flea Market", "Sunset Cruise", "Casino Night"],
        "food": ["Goan Cuisine", "Seafood", "Continental"], "travel_style": "Fun", "rating": 4.4,
    },
    {
        "destination": "Manali", "state": "Himachal Pradesh",
        "categories": ["Adventure", "Nature", "Snow"],
        "budget_level": "Medium", "average_daily_cost": 3800, "minimum_days": 4,
        "best_months": ["March", "April", "May", "June", "December"],
        "activities": ["Solang Valley", "Rohtang Pass", "River Rafting", "Paragliding",
                        "Hidimba Temple", "Old Manali Café Walk"],
        "food": ["Himachali Cuisine", "Tibetan", "Vegetarian"], "travel_style": "Adventure", "rating": 4.6,
    },
    {
        "destination": "Jaipur", "state": "Rajasthan",
        "categories": ["Heritage", "Culture", "History"],
        "budget_level": "Medium", "average_daily_cost": 3300, "minimum_days": 3,
        "best_months": ["October", "November", "December", "January", "February"],
        "activities": ["Amber Fort", "City Palace", "Hawa Mahal", "Nahargarh Fort Sunset",
                        "Local Bazaar Shopping", "Chokhi Dhani Cultural Evening"],
        "food": ["Rajasthani Cuisine", "Vegetarian"], "travel_style": "Cultural", "rating": 4.7,
    },
    {
        "destination": "Rishikesh", "state": "Uttarakhand",
        "categories": ["Adventure", "Spiritual", "Nature"],
        "budget_level": "Low", "average_daily_cost": 2200, "minimum_days": 2,
        "best_months": ["September", "October", "November", "February", "March"],
        "activities": ["River Rafting", "Bungee Jumping", "Laxman Jhula", "Ganga Aarti",
                        "Yoga Retreat", "Camping by the Ganges"],
        "food": ["Vegetarian", "Satvik"], "travel_style": "Adventure", "rating": 4.5,
    },
    {
        "destination": "Andaman Islands", "state": "Andaman & Nicobar",
        "categories": ["Beach", "Adventure", "Romantic"],
        "budget_level": "High", "average_daily_cost": 5500, "minimum_days": 4,
        "best_months": ["November", "December", "January", "February", "March"],
        "activities": ["Radhanagar Beach", "Scuba Diving", "Cellular Jail Light Show",
                        "Neil Island Snorkeling", "Glass Bottom Boat Ride"],
        "food": ["Seafood", "Continental"], "travel_style": "Relaxed", "rating": 4.8,
    },
    {
        "destination": "Udaipur", "state": "Rajasthan",
        "categories": ["Heritage", "Romantic", "Culture"],
        "budget_level": "Medium", "average_daily_cost": 3600, "minimum_days": 3,
        "best_months": ["September", "October", "November", "December", "January", "February"],
        "activities": ["City Palace", "Lake Pichola Boat Ride", "Jag Mandir", "Saheliyon Ki Bari",
                        "Sunset at Fateh Sagar Lake"],
        "food": ["Rajasthani Cuisine", "Vegetarian"], "travel_style": "Romantic", "rating": 4.7,
    },
    {
        "destination": "Darjeeling", "state": "West Bengal",
        "categories": ["Nature", "Hill Station", "Tea"],
        "budget_level": "Low", "average_daily_cost": 2600, "minimum_days": 3,
        "best_months": ["March", "April", "May", "October", "November"],
        "activities": ["Tiger Hill Sunrise", "Tea Garden Walk", "Toy Train Ride",
                        "Padmaja Naidu Zoo", "Peace Pagoda"],
        "food": ["Bengali Cuisine", "Tibetan", "Vegetarian"], "travel_style": "Relaxed", "rating": 4.4,
    },
    {
        "destination": "Hampi", "state": "Karnataka",
        "categories": ["Heritage", "History", "Adventure"],
        "budget_level": "Low", "average_daily_cost": 2000, "minimum_days": 2,
        "best_months": ["October", "November", "December", "January", "February"],
        "activities": ["Virupaksha Temple", "Vittala Temple Stone Chariot", "Matanga Hill Sunrise",
                        "Coracle Ride on Tungabhadra", "Bouldering"],
        "food": ["South Indian", "Vegetarian"], "travel_style": "Cultural", "rating": 4.5,
    },
]


def seed_destinations():
    if destinations_collection.count_documents({}) > 0:
        print("[seed_destinations] Destinations already present — skipping.")
        return
    destinations_collection.insert_many(DESTINATIONS)
    print(f"[seed_destinations] Inserted {len(DESTINATIONS)} destinations.")


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    seed_destinations()
