"""
Seeds (or updates the password hash for) the admin account from your .env
file. Runs automatically on every backend startup, so you never have to
insert the admin document into MongoDB by hand.
"""
import os
import uuid

from database.mongodb import admins_collection
from utils.security import hash_password


def seed_admin():
    email = os.getenv("ADMIN_EMAIL")
    password = os.getenv("ADMIN_PASSWORD")
    name = os.getenv("ADMIN_NAME", "Admin")

    if not email or not password:
        print("[seed_admin] ADMIN_EMAIL / ADMIN_PASSWORD not set in .env — skipping admin seed.")
        return

    existing = admins_collection.find_one({"email": email})
    hashed = hash_password(password)

    if existing:
        admins_collection.update_one({"email": email}, {"$set": {"password_hash": hashed, "name": name}})
        print(f"[seed_admin] Admin account already exists — refreshed credentials for {email}")
    else:
        admins_collection.insert_one(
            {
                "admin_id": f"ADM{uuid.uuid4().hex[:8].upper()}",
                "name": name,
                "email": email,
                "password_hash": hashed,
                "role": "admin",
            }
        )
        print(f"[seed_admin] Admin account created: {email}")


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()
    seed_admin()
