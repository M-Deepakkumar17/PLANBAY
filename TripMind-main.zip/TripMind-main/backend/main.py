from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database.mongodb import ensure_indexes, check_connection
from seed.seed_admin import seed_admin
from seed.seed_destinations import seed_destinations

from routes import auth, users, recommendations, itinerary, feedback, admin

app = FastAPI(
    title="TripMind AI Travel Assistant",
    description="AI-Powered Intelligent Travel Planning and Personalized Itinerary Recommendation System",
    version="1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    try:
        ensure_indexes()
        seed_admin()
        seed_destinations()
    except Exception as e:
        # Don't crash the app if MongoDB isn't running yet during dev.
        print(f"[startup] Warning: {e}")


@app.get("/")
def home():
    return {"message": "TripMind AI Travel Assistant API", "docs": "/docs"}


@app.get("/health")
def health():
    return {"status": "ok", "mongodb_connected": check_connection()}


app.include_router(auth.router)
app.include_router(users.router)
app.include_router(recommendations.router)
app.include_router(itinerary.router)
app.include_router(feedback.router)
app.include_router(admin.router)
